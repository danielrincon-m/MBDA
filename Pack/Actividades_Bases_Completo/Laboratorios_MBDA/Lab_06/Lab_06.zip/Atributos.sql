alter table ciudadanos add constraint ck_ciudadanos_correo check (correo like '%@%.%');

alter table colaboraciones add constraint ck_colaboraciones_estado check (estado in ('F','E','A','R'));

alter table reservas add constraint ck_reservas_estado check (estado in ('R','E','C'));

alter table ubicadaen add constraint ck_ubicadaen_porcentaje check (porcentaje > 0 and porcentaje <= 100);

alter table fotos add constraint ck_fotos_url check ((url like 'http://www.%.org/%' or url like 'https://www.%.org/%') and (url like '%.pdf' or url like '%.flv' or url like '%.jpg'));

alter table archivos add constraint ck_archivos_archivo check (archivo like 'http://www.%.org%' or archivo like 'https://www.%.org%');

alter table departamentos modify nombre varchar(25) not null;

alter table unidades modify nombre varchar(30) not null;

alter table ubicadaen modify porcentaje number(3) not null;

alter table reservas modify fecha date not null;

alter table reservas modify estado char(1) not null;

alter table fotos modify url varchar(50) not null;

alter table fotos modify autor varchar(50) not null;

alter table colaboraciones modify fecha date not null;

alter table colaboraciones modify descripcion varchar(100) not null;

alter table colaboraciones modify estado char(1) not null;

alter table colaboraciones modify realiza number(15) not null;

alter table colaboraciones modify funcionario number(15) not null;

alter table funcionarios modify vinculacion date not null;

alter table ciudadanos modify nombre varchar(50) not null;

alter table ciudadanos modify correo varchar(50) not null;

alter table ciudadanos modify unidadnum number(2) not null;

alter table ciudadanos modify unidaddpto char(3) not null;