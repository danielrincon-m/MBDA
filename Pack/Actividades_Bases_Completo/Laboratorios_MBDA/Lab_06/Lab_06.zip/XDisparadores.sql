drop trigger reg_colaboraciones;

drop trigger eli_colaboraciones;

drop trigger mod_colaboraciones1;

drop trigger mod_colaboraciones2;

drop trigger agr_fotos;

drop trigger reg_reserva;

drop trigger no_modificar_reserva;

drop trigger no_modificar_reserva_2;

drop trigger porcentaje;

drop trigger mod_estado;

drop trigger agr_departamentos;

drop trigger mod_departamentos;

drop trigger agr_unidades;

drop trigger mod_unidades;