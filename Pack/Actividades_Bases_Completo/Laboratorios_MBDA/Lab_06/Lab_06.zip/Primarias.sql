alter table departamentos add constraint pk_departamentos primary key (identificador);

alter table unidades add constraint pk_unidades primary key (numero, departamento);

alter table reservas add constraint pk_reservas primary key (nombre);

alter table ubicadaen add constraint pk_ubicadaen primary key (unidadnum, unidaddpto, reserva);

alter table fotos add constraint pk_fotos primary key (numero, reserva);

alter table ciudadanos add constraint pk_ciudadanos primary key (cedula);

alter table funcionarios add constraint pk_funcionarios primary key (cedula);

alter table esconocidapor add constraint pk_esconocidapor primary key (reserva, funcionario);

alter table colaboraciones add constraint pk_colaboraciones primary key (numero);

alter table archivos add constraint pk_archivos primary key (numero, colaboracion);