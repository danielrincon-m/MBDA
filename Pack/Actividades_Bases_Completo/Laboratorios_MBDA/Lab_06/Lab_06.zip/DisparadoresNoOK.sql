update departamentos set identificador = 'AAA';

update unidades set departamento = 'AAA';

update reservas set nombre = 'lelelele';

update reservas set fecha = sysdate;

update reservas set estado = 'C' where estado = 'E';

insert into ubicadaen (unidadnum, unidaddpto, reserva, porcentaje) values (1,'CUN','Lilith',3);
update ubicadaen set porcentaje = 40 where unidadnum = 2 and unidaddpto = 'SAN';