insert into departamentos (nombre) values ('Santander');
insert into departamentos (nombre) values ('Boyac�');
insert into departamentos (nombre) values ('San Andr�s y Providencia');
insert into departamentos (nombre) values ('Cundinamarca');
insert into departamentos (nombre) values ('Magdalena');

insert into unidades (departamento, nombre) values ('CUN', 'Bogot�');
insert into unidades (departamento, nombre) values ('CUN', 'Guaduas');
insert into unidades (departamento, nombre) values ('CUN', 'La Mesa');
insert into unidades (departamento, nombre) values ('SAN', 'Bucaramanga');
insert into unidades (departamento, nombre) values ('SAN', 'Barrancabermeja');
insert into unidades (departamento, nombre) values ('MAG', 'Santa Marta');

insert into reservas (nombre, detalle) values ('Valhalla', 'Reserva Valhalla');
insert into reservas (nombre, detalle) values ('Asgard', 'Reserva Asgard');
insert into reservas (nombre, detalle) values ('Lilith', 'Reserva Lilith');
insert into reservas (nombre, detalle) values ('SNevada', 'Reserva S.Nevada');

insert into fotos values (1, 'Lilith', 'http://www.lilith.org/lilith_1.flv', 'Ana Mar�a');
insert into fotos values (2, 'Lilith', 'http://www.lilith.org/lilith_2.jpg', 'Alejandra Gamboa');

insert into ubicadaen (unidadnum, unidaddpto, reserva, porcentaje) values (2,'SAN','Lilith',38);
insert into ubicadaen (unidadnum, unidaddpto, reserva, porcentaje) values (1,'SAN','Lilith',62);
insert into ubicadaen (unidadnum, unidaddpto, reserva, porcentaje) values (1,'MAG','SNevada',100);

insert into ciudadanos values (1018477265, 'Camilo Andr�s Torres Torres', 'camandto@hotmail.com', 2, 'SAN');
insert into ciudadanos values (1219657442, 'Ana Mar�a G�mez Jaimes', 'anmagoja0207@hotmail.com', 1, 'SAN');
insert into ciudadanos values (28015747, 'Nancy Mar�a Torres Mier', 'camandto@hotmail.com', 1, 'MAG');
insert into ciudadanos values (1019447221, 'Mar�a Fernanda Montoya Qui�onez', 'fernanda.montoya1002@yahoo.es', 1, 'CUN');
insert into ciudadanos values (123456789, 'Luciana Castro Torres', 'lucisan@colsanitas.com.co', 1, 'CUN');

insert into funcionarios values (1018477265, sysdate);
insert into funcionarios values (1019447221, sysdate);
insert into funcionarios values (123456789, sysdate);

insert into colaboraciones (descripcion, sintesis, reserva, realiza) values ('Reserva para borrar', 'Que es esto', 'Lilith', 1018477265);
insert into colaboraciones (descripcion, sintesis, reserva, realiza) values ('Reserva para borrar2', 'Que es esto', 'SNevada', 28015747);