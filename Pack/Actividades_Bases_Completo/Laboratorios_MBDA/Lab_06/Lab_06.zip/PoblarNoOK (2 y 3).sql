-- 2

-- Nombre de reserva de m�s de 10 caracteres

insert into reservas values ('Nombredereservalargo', sysdate, 'R', null);

-- Identificador de departamento de m�s de 3

insert into departamentos values ('DEPTO', 'Ejemplo');

-- Numero de archivo de m�s de 2 d�gitos

insert into archivos values (123, 123, 'archivo');

-- Numero de Colaboraci�n de m�s de 5 digitos

insert into archivos values (2, 123456, 'archivo2');

-- 3

-- Url inv�lida

insert into fotos values (3, 'Lilith', 'urlmala.com', 'Ana Mar�a');

-- Departamento Inv�lido

insert into departamentos values ('ABC', 'Zeta');