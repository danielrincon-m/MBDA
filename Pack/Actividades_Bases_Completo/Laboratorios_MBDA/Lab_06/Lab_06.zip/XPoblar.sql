delete from archivos;

delete from colaboraciones;

delete from esconocidapor;

delete from funcionarios;

delete from ciudadanos;

delete from fotos;

delete from ubicadaen;

delete from reservas;

delete from unidades;

delete from departamentos;