alter table unidades add constraint fk_unidades_departamentos foreign key (departamento) references departamentos (identificador);

alter table ubicadaen add constraint fk_ubicadaen_unidades foreign key (unidadnum, unidaddpto) references unidades (numero, departamento);

alter table ubicadaen add constraint fk_ubicadaen_reservas foreign key (reserva) references reservas (nombre);

alter table fotos add constraint fk_fotos_reservas foreign key (reserva) references reservas (nombre);

alter table ciudadanos add constraint fk_ciudadanos_unidades foreign key (unidadnum, unidaddpto) references unidades (numero, departamento);

alter table funcionarios add constraint fk_funcionarios_ciudadanos foreign key (cedula) references ciudadanos (cedula);

alter table esconocidapor add constraint fk_esconocidapor_reservas foreign key (reserva) references reservas (nombre);

alter table esconocidapor add constraint fk_esconocidapor_funcionarios foreign key (funcionario) references funcionarios (cedula);

alter table colaboraciones add constraint fk_colaboraciones_reservas foreign key (reserva) references reservas (nombre);

alter table colaboraciones add constraint fk_colab_ciud_realiza foreign key (realiza) references ciudadanos (cedula);

alter table colaboraciones add constraint fk_colab_ciud_estestigo foreign key (estestigo) references ciudadanos (cedula);

alter table colaboraciones add constraint fk_colaboraciones_funcionarios foreign key (funcionario) references funcionarios (cedula);

alter table archivos add constraint fk_archivos_colaboraciones foreign key (colaboracion) references colaboraciones (numero);