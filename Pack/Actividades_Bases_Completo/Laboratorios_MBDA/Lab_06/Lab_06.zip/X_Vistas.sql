--****************************
--X_Vistas
--****************************
drop view nombres_reservas;
drop view colaboraciones_reserva;
drop view unidades_reserva;
drop view detalles_reserva;
drop view informacion_fotos;
drop view ciudadanos_reserva;
drop view info_reserva;
drop view correo_ciudadano;
drop view detalles_colaboracion_reserva;
