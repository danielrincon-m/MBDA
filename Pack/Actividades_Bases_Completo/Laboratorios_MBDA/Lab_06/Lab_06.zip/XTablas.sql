drop table archivos;

drop table colaboraciones;

drop table fotos;

drop table ubicadaen;

drop table esconocidapor;

drop table funcionarios;

drop table reservas;

drop table ciudadanos;

drop table unidades;

drop table departamentos;