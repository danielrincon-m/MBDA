select colaboraciones.numero, colaboraciones.fecha, colaboraciones.estado, ciudadanos.nombre, x.pendientes 
from (select cedula, count(numero) as pendientes from colaboraciones, funcionarios
where colaboraciones.funcionario = funcionarios.cedula and estado = 'E'
group by funcionarios.cedula) x, colaboraciones, ciudadanos
where x.cedula = ciudadanos.cedula and x.cedula = colaboraciones.funcionario;

select cedula  from colaboraciones, funcionarios
where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E', 'F') group by cedula
having count(colaboraciones.numero) <= all(select count(colaboraciones.numero)
from colaboraciones, funcionarios where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E','F'));