alter table archivos drop constraint fk_archivos_colaboraciones;
alter table archivos add constraint fk_archivos_colaboraciones foreign key (colaboracion) references colaboraciones (numero) on delete cascade;

alter table fotos drop constraint fk_fotos_reservas;
alter table fotos add constraint fk_fotos_reservas foreign key (reserva) references reservas(nombre) on delete cascade;

alter table ubicadaen drop constraint fk_ubicadaen_reservas;
alter table ubicadaen add constraint fk_ubicadaen_reservas foreign key (reserva) references reservas (nombre) on delete cascade;

alter table esconocidapor drop constraint fk_esconocidapor_reservas;
alter table esconocidapor add constraint fk_esconocidapor_reservas foreign key (reserva) references reservas (nombre) on delete cascade;

alter table unidades drop constraint fk_unidades_departamentos;
alter table unidades add constraint fk_unidades_departamentos foreign key (departamento) references departamentos (identificador);

alter table ubicadaen drop constraint fk_ubicadaen_unidades;
alter table ubicadaen add constraint fk_ubicadaen_unidades foreign key (unidadnum, unidaddpto) references unidades (numero, departamento) on delete cascade;

alter table colaboraciones drop constraint fk_colab_ciud_estestigo;
alter table colaboraciones add constraint fk_colab_ciud_estestigo foreign key (estestigo) references ciudadanos (cedula) on delete set null;