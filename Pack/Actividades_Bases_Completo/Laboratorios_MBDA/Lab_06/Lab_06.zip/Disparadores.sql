--Mantener Colaboraciones

create or replace trigger reg_colaboraciones
before insert on colaboraciones
for each row
declare
cvivenum number(2); cvivedpto char(3);
x number(15);
begin
select unidadnum into cvivenum from ciudadanos where cedula = :new.realiza;
select unidaddpto into cvivedpto from ciudadanos where cedula = :new.realiza;
select count(*) into x from ubicadaen where unidadnum = cvivenum and unidaddpto = cvivedpto
and reserva = :new.reserva;
dbms_output.put_line(x);
if(x=0)then
Raise_Application_Error(-20000, 'Error ciudadano');
end if;
select cedula into :new.funcionario from colaboraciones, funcionarios
where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E', 'F') group by cedula
having count(colaboraciones.numero) <= all(select count(colaboraciones.numero)
from colaboraciones, funcionarios where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E','F'));
select count(*)+1 into :new.numero from colaboraciones;
:new.fecha := sysdate;
:new.estado := 'E';
end;

create or replace trigger eli_colaboraciones
before delete on colaboraciones
for each row
begin
if(sysdate - :old.fecha <= 15 or :old.estado != 'E')then
raise_application_error(-20000, 'Error estado');
end if;
end;

create or replace trigger mod_colaboraciones1
before update of estado on colaboraciones
for each row
declare x int; y int; z int;
begin
if(:old.estado != 'E' or :new.estado != 'F')then
raise_application_error(-20000, 'Error estado');
end if;
select count(*) into x from archivos where archivo like '%.pdf' and colaboracion = :old.numero;
select count(*) into y from archivos where archivo like '%.flv' and colaboracion = :old.numero;
select count(*) into z from archivos where archivo like '%.jpg' and colaboracion = :old.numero;
dbms_output.put_line(concat('Archivos en pdf: ',x));
dbms_output.put_line(concat('Archivos en flv: ',y));
dbms_output.put_line(concat('Archivos en jpg: ',z));
end;

create or replace trigger mod_colaboraciones2
before update of estado on colaboraciones
for each row
declare x int; y int; z int; r varchar(10); n varchar(50); foto varchar(50);
cursor urls is (select archivo from archivos where colaboracion = :old.numero);
begin
if(:old.estado != 'F' or :new.estado != 'A' or :new.estado != 'R')then
raise_application_error(-20000, 'Error estado');
if(:new.estado = 'A')then
select nombre into n from ciudadanos where cedula = :old.realiza;
open urls;
loop
fetch urls into foto;
exit when urls%NOTFOUND;
insert into fotos(reserva, url, autor) values (:old.reserva, foto, n);
end loop;
close urls;
select estado into r from reservas where nombre = :old.reserva;
if(r = 'E')then
update reservas set estado = 'R' where nombre = :old.reserva;
end if;
end if;
end if;
end;

create or replace trigger agr_fotos
before insert on fotos
for each row
begin
select count(*)+1 into :new.numero from fotos where reserva = :new.reserva;
end;

--Mantener Reservas

create or replace trigger reg_reserva
before insert on reservas
for each row
begin
:new.fecha := sysdate;
:new.estado := 'E';
end;

create or replace trigger no_modificar_reserva
before update of nombre on reservas
begin
raise_application_error(-20000, 'Accion no permitida');
end;

create or replace trigger no_modificar_reserva_2
before update of fecha on reservas
begin
raise_application_error(-20000, 'Accion no permitida');
end;

create or replace trigger porcentaje
after insert or update of porcentaje on ubicadaen
declare cursor porcentajes is (select sum(porcentaje) from ubicadaen group by reserva); x int;
begin
open porcentajes;
loop
fetch porcentajes into x;
exit when porcentajes%NOTFOUND;
if(x>100 or x<=0)then
raise_application_error(-20000, 'Error porcentaje');
end if;
end loop;
close porcentajes;
end;

create or replace trigger mod_estado
before update of estado on reservas
for each row
begin
if(:old.estado = 'E' and :new.estado != 'R')then
raise_application_error(-20000,'Error estado');
elsif(:old.estado = 'R' and :new.estado != 'C')then
raise_application_error(-20000,'Error estado');
end if;
end;

--Mantener Unidades/Departamentos

create or replace trigger agr_departamentos
before insert on departamentos
for each row
declare id char(3); x int;
begin
id := upper(substr(regexp_replace(:new.nombre, '[[:space:]]*', ''),1,3));
select count(*) into x from departamentos where identificador = id;
if(x>0)then
:new.identificador := upper(concat(substr(regexp_replace(:new.nombre, '[[:space:]]*', ''),1,2),substr(regexp_replace(:new.nombre, '[[:space:]]*', ''),4,1)));
else
:new.identificador := id;
end if;
end;

create or replace trigger mod_departamentos
before update on departamentos
begin
raise_application_error(-20000,'Accion no valida');
end;

create or replace trigger agr_unidades
before insert on unidades
for each row
declare x int;
begin
select count(*)+1 into x from unidades where departamento = :new.departamento;
:new.numero := x;
end;

create or replace trigger mod_unidades
before update of departamento on unidades
begin
raise_application_error(-20000,'Accion no valida');
end;