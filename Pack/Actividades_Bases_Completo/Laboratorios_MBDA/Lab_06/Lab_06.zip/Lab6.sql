--Insertar en mbda01.datos
insert into mbda01.datos (cedula, nombre, correo, fecha) values (1018477265, 'Camilo Andres Torres Torres', 'camandto@hotmail.com', sysdate);
commit;

--Copia los datos a una nueva tabla datos en mi cuenta
create table datos (cedula number(10), nombre varchar(50), correo varchar(50), fecha date);

create or replace procedure importar_datos is
cursor transfer is select * from mbda01.datos;
begin
for x in transfer loop
insert into datos (cedula, nombre, correo, fecha) values (x.cedula, x.nombre, x.correo, x.fecha);
end loop;
commit;
end;

--Esto lo deber�a ejecutar el administrador, para poder borrar los datos en mbda01.datos. me es el usuario que requerir�a los permisos.
grant delete on mbda01.datos to me;

--CRUD Colaboradores. Especificaci�n
create or replace package mantener_ciudadanos is
procedure agregar_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char);
procedure consultar_ciudadano (cc number);
procedure modificar_ciudadano (cc number, ncorreo varchar);
procedure eliminar_ciudadano (cc number);
end mantener_ciudadanos;

create or replace package mantener_funcionarios is
procedure agregar_funcionario_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char, fecha_vinc date);
procedure agregar_funcionario (cc number, fecha_vinc date);
procedure consultar_funcionario (cc number);
procedure modificar_funcionario (cc number, ncorreo varchar);
procedure eliminar_funcionario (cc number);
end mantener_funcionarios;

--CRUD Colaboradores. Implementaci�n
create or replace package body mantener_ciudadanos is
procedure agregar_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char) is
begin
insert into ciudadanos (cedula, nombre, correo, unidadnum, unidaddpto) values (cc, nnombre, ccorreo, unum, udpto);
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure consultar_ciudadano (cc number) is
begin
select * from ciudadanos where cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure modificar_ciudadano (cc number, ncorreo varchar) is
begin
update ciudadanos set correo = ncorreo where cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure eliminar_ciudadano (cc number) is
begin
delete from ciudadanos where cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
end mantener_ciudadanos;

create or replace package body mantener_funcionarios is
procedure agregar_funcionario_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char, fecha_vinc date) is
begin
mantener_ciudadanos.agregar_ciudadano (cc, nnombre, ccorreo, unum, udpto);
insert into funcionarios (cedula, vinculacion) values (cc, fecha_vinc);
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure agregar_funcionario (cc number, fecha_vinc date) is
begin
insert into funcionarios (cedula, vinculacion) values (cc, fecha_vinc);
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure consultar_funcionario (cc number) is
begin
select * funcionarios wher cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure modificar_funcionario (cc number, ncorreo varchar) is
begin
update ciudadanos set correo = ncorreo where cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure eliminar_funcionario (cc number) is
begin
delete from funcionarios where cedula = cc;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
end mantener_funcionarios;

--CRUD Colaboraciones. Especificaci�n

create or replace package consultas is
procedure registrar_colaboracion (numero number, fecha date, descripcion varchar, estado char, sintesis varchar, fechaCierre date, reserva varchar, realiza number, estestigo number, funcionario number);
procedure agregar_archivos (numero number, colaboracion number, archivo varchar);
procedure eliminar_colaboracion (num number);
procedure eliminar_archivos (colab number);
end consultas;

--CRUD Colaboraciones. Implementaci�n

create or replace package body consultas is
procedure registrar_colaboracion (numero number, fecha date, descripcion varchar, estado char, sintesis varchar, fechaCierre date, reserva varchar, realiza number, estestigo number, funcionario number) is
begin
insert into colaboraciones values (numero, fecha, descripcion, estado, sintesis, fechaCierre, reserva, realiza, estestigo, funcionario);
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure agregar_archivos (numero number, colaboracion number, archivo varchar) is
begin
insert into archivos values (numero, colaboracion, archivo);
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure eliminar_colaboracion (num number) is
begin
delete from colaboraciones where numero = num;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure eliminar_archivos (colab number) is
begin
delete from archivos where colaboracion = colab;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
end consultas;

--Consultas. Especificaci�n

create or replace package consultas is
procedure consultar_estado_colaboraciones;
procedure importar_datos;
procedure consultar_colaboraciones_pendientes;
procedure consultar_testigos_rechazadas;
end consultas;

--Consultas. Implementaci�n

create or replace package consultas is
procedure consultar_estado_colaboraciones is
begin
select numero, estado from colaboraciones;
end;
procedure importar_datos is
begin
cursor transfer is select * from mbda01.datos;
begin
for x in transfer loop
insert into datos (cedula, nombre, correo, fecha) values (x.cedula, x.nombre, x.correo, x.fecha);
end loop;
commit;
exception
when others then
rollback;
raise_application_error(20001, 'Error');
end;
procedure consultar_colaboraciones_pendientes is
begin
select colaboraciones.numero, colaboraciones.fecha, colaboraciones.estado, ciudadanos.nombre, x.pendientes 
from (select cedula, count(numero) as pendientes from colaboraciones, funcionarios
where colaboraciones.funcionario = funcionarios.cedula and estado = 'E'
group by funcionarios.cedula) x, colaboraciones, ciudadanos
where x.cedula = ciudadanos.cedula and x.cedula = colaboraciones.funcionario;
end;
procedure consultar_testigos_rechazadas is
begin
select cedula  from colaboraciones, funcionarios
where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E', 'F') group by cedula
having count(colaboraciones.numero) <= all(select count(colaboraciones.numero)
from colaboraciones, funcionarios where colaboraciones.funcionario = funcionarios.cedula
and colaboraciones.estado in ('E','F'));
end;
end consultas;

--Seguridad. Especificaci�n

create or replace package administrador is
procedure seg_agregar_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char);
procedure seg_consultar_ciudadano (cc number);
procedure seg_modificar_ciudadano (cc number, ncorreo varchar);
procedure seg_eliminar_ciudadano (cc number);
procedure seg_agregar_funcionario_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char, fecha_vinc date);
procedure seg_agregar_funcionario (cc number, fecha_vinc date);
procedure seg_consultar_funcionario (cc number);
procedure seg_modificar_funcionario (cc number, ncorreo varchar);
procedure seg_eliminar_funcionario (cc number);
procedure consultar_estado_colaboraciones;
procedure importar_datos;
end administrador;

create or replace package funcionario is
procedure seg_registrar_colaboracion (numero number, fecha date, descripcion varchar, estado char, sintesis varchar, fechaCierre date, reserva varchar, realiza number, estestigo number, funcionario number);
procedure seg_agregar_archivos (numero number, colaboracion number, archivo varchar);
procedure seg_eliminar_colaboracion (num number);
procedure seg_eliminar_archivos (colab number);
end funcionario;

--Seguridad. Implementaci�n

create or replace package body administrador is
procedure seg_agregar_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char) is
begin
mantener_ciudadanos.agregar_ciudadano (cc, nnombre, ccorreo, unum, udpto);
end;
procedure seg_consultar_ciudadano (cc number) is
begin
mantener_ciudadanos.consultar_ciudadano (cc);
end;
procedure seg_modificar_ciudadano (cc number, ncorreo varchar) is
begin
mantener_ciudadanos.modificar_ciudadano (cc, ncorreo);
end;
procedure seg_eliminar_ciudadano (cc number) is
begin
mantener_ciudadanos.eliminar_ciudadano (cc);
end;
procedure seg_agregar_funcionario_ciudadano (cc number, nnombre varchar, ccorreo varchar, unum number, udpto char, fecha_vinc date) is
begin
mantener_funcionarios.agregar_funcionario_ciudadano (cc, nnombre, ccorreo, unum, udpto, fecha_vinc);
end;
procedure seg_agregar_funcionario (cc number, fecha_vinc date) is
begin
mantener_funcionarios.agregar_funcionario (cc, fecha_vinc);
end;
procedure seg_consultar_funcionario (cc number) is
begin
mantener_funcionarios.consultar_funcionario (cc);
end;
procedure seg_modificar_funcionario (cc number, ncorreo varchar) is
begin
mantener_funcionarios.modificar_funcionario (cc, ncorreo);
end;
procedure seg_eliminar_funcionario (cc number) is
begin
mantener_funcionarios.eliminar_funcionario (cc);
end;
procedure consultar_estado_colaboraciones is
begin
consultas.consultar_estado_colaboraciones;
end;
procedure importar_datos is
begin
consultas.importar_datos;
end;
end administrador;

create or replace package body funcionario is
procedure seg_registrar_colaboracion (numero number, fecha date, descripcion varchar, estado char, sintesis varchar, fechaCierre date, reserva varchar, realiza number, estestigo number, funcionario number) is
begin
registrar_colaboraciones.registrar_colaboracion (numero, fecha, descripcion, estado, sintesis, fechaCierre, reserva, realiza, estestigo, funcionario);
end;
procedure seg_agregar_archivos (numero number, colaboracion number, archivo varchar) is
begin
registrar_colaboraciones.agregar_archivos (numero, colaboracion, archivo);
end;
procedure seg_eliminar_colaboracion (num number) is
begin
registrar_colaboraciones.eliminar_colaboracion (num);
end;
procedure seg_eliminar_archivos (colab number) is
begin
registrar_colaboraciones.eliminar_archivos (colab);
end;
end funcionario;

grant execute on administrador to unAdministrador;
grant execute on funcionario to unFuncionario;

--ComponentesOK

execute mantener_ciudadanos.agregar_funcionario (1020456978, 'Juan Arkangel El Pra', 'arkan_pra@hotmail.com', 10203045, 'E', to_date('2007-02-07 00:00:00', 'yyyy-mm-dd hh24:mi:ss'));
execute mantener_ciudadanos.consultar_ciudadano (1020456978);
execute mantener_ciudadanos.modificar_ciudadano (1020456978, 'arkan_pra@hotmail.com');
execute mantener_ciudadanos.eliminar_ciudadano (1020456978);

execute mantener_funcionarios.agregar_funcionario_ciudadano (1020304050, 'Rick The Walking Deada', 'rick_neagan@hotmail.com',10203040, 'E', to_date('2012-02-12 00:00:00', 'yyyy-mm-dd hh24:mi:ss'));
execute mantener_funcionarios.agregar_funcionario (1020649845,to_date('2012-02-12 00:00:00', 'yyyy-mm-dd hh24:mi:ss'));
execute mantener_funcionarios.modificar_funcionario (1020304050,'rick_neagan@hotmail.com');
execute mantener_funcionarios.eliminar_funcionario(1020304050);

--ComponentesNoOK

execute mantener_ciudadanos.agregar_funcionario ('Juan Arkangel El Pra',1020456978,to_date('2007-02-07 00:00:00', 'yyyy-mm-dd hh24:mi:ss') , 10203045, 'E', 'arkan_pra@hotmail.com');
execute mantener_ciudadanos.consultar_ciudadano ('Juan Arkangel El Pra');
execute mantener_ciudadanos.modificar_ciudadano ('arkan_pra@hotmail.com', 1020456978);
execute mantener_ciudadanos.eliminar_ciudadano ('arkan_pra@hotmail.com');

execute mantener_funcionarios.agregar_funcionario_ciudadano ('Rick The Walking Deada','rick_neagan@hotmail.com' ,'E',10203040, 1020304050, to_date('2012-02-12 00:00:00', 'yyyy-mm-dd hh24:mi:ss'));
execute mantener_funcionarios.agregar_funcionario (to_date('2012-02-12 00:00:00', 'yyyy-mm-dd hh24:mi:ss'),1020649845);
execute mantener_funcionarios.modificar_funcionario ('rick_neagan@hotmail.com',1020304050);
execute mantener_funcionarios.eliminar_funcionario('rick_neagan@hotmail.com');

--Indices
create index nombre_departamento on departamentos(nombre);
create index nombre_unididades on unidades(nombre);
create index url_foto on fotos(url);
create index autor_foto on fotos(autor);
create index nombre_ciudadanos on ciudadanos(nombre);
create index funcionario_colaboraciones on colaboraciones(funcionario);
create index arch_archivos on archivos(archivo);
create index vinculacion_funcionario on funcionarios(vinculacion);