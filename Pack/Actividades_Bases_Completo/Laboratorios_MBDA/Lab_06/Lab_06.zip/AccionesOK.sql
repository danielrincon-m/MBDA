delete from departamentos where identificador = 'SAN' or identificador = 'MAG';

insert into unidades (departamento, nombre) values ('MAG', 'Costa');
insert into ubicadaen (unidadnum, unidaddpto, reserva, porcentaje) values (2,'MAG','Asgard',10);
delete from unidades where nombre = 'Costa';

delete from reservas where nombre = 'Lilith';