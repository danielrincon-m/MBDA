create table departamentos (identificador char(3), nombre varchar(25));

create table unidades (numero number(2), departamento char(3), nombre varchar(30));

create table reservas (nombre varchar(10), fecha date, estado char(1), detalle varchar(100));

create table ubicadaen (unidadnum number(2), unidaddpto char(3), reserva varchar(10), porcentaje number(3));

create table fotos (numero number(2), reserva varchar(10), url varchar(50), autor varchar(50));

create table ciudadanos (cedula number(15), nombre varchar(50), correo varchar(50), unidadnum number(2), unidaddpto char(3));

create table funcionarios (cedula number(15), vinculacion date);

create table esconocidapor (reserva varchar(10), funcionario number(15));

create table colaboraciones (numero number(5), fecha date, descripcion varchar(100), estado char(1), sintesis varchar(50), fechaCierre date, reserva varchar(10), realiza number(15), estestigo number(15), funcionario number(15));

create table archivos (numero number(2), colaboracion number(5), archivo varchar(50));