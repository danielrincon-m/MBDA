--****************************
--Vistas
--****************************
create or replace view nombres_reservas
as(
select (nombre) from reservas, fotos
where reservas.nombre = fotos.reserva
);


create or replace view colaboraciones_reserva
as(
select * from colaboraciones where
colaboraciones.reserva = (select nombre from reservas
)
);

create or replace view unidades_reserva 
as(
select numero, unidades.nombre as unidades_por_reserva from unidades 
where unidades.nombre =(
select nombre from reservas
)
);

create or replace view detalles_reserva
as(
select nombre, detalle as detalle_reserva from 
reservas
);

create or replace view informacion_fotos
as(
select fotos.url as sitio_web_foto, fotos.autor as autor_fotos
from fotos
);

create or replace view ciudadanos_reserva
as(
select ciudadanos.nombre as nombre_ciudadano, colaboraciones.reserva 
from colaboraciones, ciudadanos
where ciudadanos.cedula = colaboraciones.funcionario
);

create or replace view info_reserva
as(
select reservas.nombre as nombre_reserva,
reservas.detalle as info_reservas
from reservas
);

create or replace view correo_ciudadano
as(
select ciudadanos.cedula as cedula_ciudadano,
ciudadanos.correo as correo_ciudadano
from ciudadanos
);

create or replace view detalles_colaboracion_reserva
as(
select colaboraciones.reserva as nombre_reserva, colaboraciones.descripcion as descripcion_colaboracion
from colaboraciones
);
