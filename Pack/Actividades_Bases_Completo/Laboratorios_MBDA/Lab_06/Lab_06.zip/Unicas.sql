alter table unidades add constraint uk_unidades_nombre unique (nombre);

alter table fotos add constraint uk_fotos_url unique (url);

alter table colaboraciones add constraint uk_colaboraciones_descripcion unique (descripcion);