-- Departamentos

insert into departamentos (identificador, nombre) values ('AMA', 'Amazonas');

insert into departamentos (identificador, nombre) values ('ARA', 'Arauca');

insert into departamentos (identificador, nombre) values ('ATL', 'Atl�ntico');

insert into departamentos (identificador, nombre) values ('BOL', 'Bol�var');

insert into departamentos (identificador, nombre) values ('BOY', 'Boyac�');

insert into departamentos (identificador, nombre) values ('CAL', 'Caldas');

insert into departamentos (identificador, nombre) values ('CAQ', 'Caquet�');

insert into departamentos (identificador, nombre) values ('CAS', 'Casanare');

insert into departamentos (identificador, nombre) values ('CAU', 'Cauca');

insert into departamentos (identificador, nombre) values ('CES', 'Cesar');

insert into departamentos (identificador, nombre) values ('CHO', 'Choc�');

insert into departamentos (identificador, nombre) values ('C�R', 'C�rdoba');

insert into departamentos (identificador, nombre) values ('CUN', 'Cundinamarca');

insert into departamentos (identificador, nombre) values ('GUA', 'Guain�a');

insert into departamentos (identificador, nombre) values ('GUV', 'Guaviare');

insert into departamentos (identificador, nombre) values ('HUI', 'Huila');

insert into departamentos (identificador, nombre) values ('LAG', 'La Guajira');

insert into departamentos (identificador, nombre) values ('MAG', 'Magdalena');

insert into departamentos (identificador, nombre) values ('MET', 'Meta');

insert into departamentos (identificador, nombre) values ('NAR', 'Nari�o');

insert into departamentos (identificador, nombre) values ('NOR', 'Norte de Santander');

insert into departamentos (identificador, nombre) values ('PUT', 'Putumayo');

insert into departamentos (identificador, nombre) values ('QUI', 'Quind�o');

insert into departamentos (identificador, nombre) values ('RIS', 'Risaralda');

insert into departamentos (identificador, nombre) values ('SAP', 'San Andr�s y Providencia');

insert into departamentos (identificador, nombre) values ('SAN', 'Santander');

insert into departamentos (identificador, nombre) values ('SUC', 'Sucre');

insert into departamentos (identificador, nombre) values ('TOL', 'Tolima');

insert into departamentos (identificador, nombre) values ('VAL', 'Valle del Cauca');

insert into departamentos (identificador, nombre) values ('VAU', 'Vaup�s');

insert into departamentos (identificador, nombre) values ('VIC', 'Vichada');

-- Unidades

insert into unidades (numero, departamento, nombre) values (1, 'AMA', 'La Pedrera');

insert into unidades (numero, departamento, nombre) values (2, 'AMA', 'Mirit�-Paran�');

insert into unidades (numero, departamento, nombre) values (7, 'SAN', 'Barrancabermeja');

insert into unidades (numero, departamento, nombre) values (1, 'SAN', 'Bucaramanga');

insert into unidades (numero, departamento, nombre) values (1, 'CUN', 'Bogot� DC');

insert into unidades (numero, departamento, nombre) values (1, 'MAG', 'Santa Marta');

insert into unidades (numero, departamento, nombre) values (1, 'SAP', 'San Andr�s');

-- Ciudadanos

insert into ciudadanos values (1018477265, 'Camilo Andr�s Torres Torres', 'camandto@hotmail.com', 7, 'SAN');

insert into ciudadanos values (1219657442, 'Ana Mar�a G�mez Jaimes', 'anmagoja0207@hotmail.com', 1, 'SAN');

insert into ciudadanos values (28015747, 'Nancy Mar�a Torres Mier', 'camandto@hotmail.com', 1, 'MAG');

insert into ciudadanos values (1019447221, 'Mar�a Fernanda Montoya Qui�onez', 'fernanda.montoya1002@yahoo.es', 1, 'CUN');

insert into ciudadanos values (123456789, 'Luciana Castro Torres', 'lucisan@colsanitas.com.co', '1', 'CUN');

-- Funcionarios

insert into funcionarios values (1018477265, sysdate);

insert into funcionarios values (1019447221, sysdate);

insert into funcionarios values (123456789, sysdate);

-- Reservas

insert into reservas values ('Valhalla', sysdate, 'E', 'Esta es la reserva Valhalla');

insert into reservas values ('Asgard', sysdate, 'E', 'Esta es la reserva Asgard');

-- Ubicada En

insert into ubicadaen values (1, 'AMA', 'Valhalla', 44);

insert into ubicadaen values (2, 'AMA', 'Valhalla', 56);

insert into ubicadaen values (1, 'AMA', 'Asgard', 100);

-- Fotos

insert into fotos values (1, 'Valhalla', 'http://www.valhalla.org/valhalla.pdf', 'Camilo Torres');

insert into fotos values (1, 'Asgard', 'http://www.asgard.org/asgard.jpg', 'Ana Mar�a');

-- Colaboraciones

insert into colaboraciones values (1, sysdate, 'Colaboracion 1', 'E', 'Sintesis 1', null, 'Asgard', 1018477265, 28015747, 1018477265);

insert into colaboraciones values (2, sysdate, 'Colaboracion 2', 'E', 'Sintesis 2', null, 'Asgard', 1219657442, 1018477265, 1019447221);

insert into colaboraciones values (3, sysdate, 'Colaboracion 3', 'F', 'Sintesis 3', null, 'Valhalla', 28015747, 1018477265, 1019447221);

-- Archivos

insert into archivos values (1, 1, 'http://www.colab1_1.org');

insert into archivos values (2, 1, 'http://www.colab1_2.org');

insert into archivos values (1, 2, 'http://www.colab2.org');

-- Todos los CRUD intervienen

-- Otras tres reservas

insert into reservas values ('Morioh', sysdate, 'C', 'Esta es la reserva Morioh');

insert into reservas values ('Lilith', sysdate, 'E', 'Esta es la reserva Lilith');

insert into reservas values ('Adam', sysdate, 'R', 'Esta es la reserva Adam');

-- Fotos

insert into fotos values (1, 'Lilith', 'http://www.lilith.org/lilith_1.flv', 'Ana Mar�a');

insert into fotos values (2, 'Lilith', 'http://www.lilith.org/lilith_2.jpg', 'Alejandra Gamboa');

insert into fotos values (1, 'Morioh', 'http://www.Morioh.org/Morioh.jpg', 'Mayra Sandoval');

-- Ubicada En

insert into ubicadaen values (7, 'SAN', 'Lilith', 30);

insert into ubicadaen values (1, 'SAN', 'Lilith', 70);

insert into ubicadaen values (1, 'SAP', 'Morioh', 100);

insert into ubicadaen values (1, 'MAG', 'Adam', 100);

-- Otras dos colaboraciones

insert into colaboraciones values (3, sysdate, 'Colaboracion 3', 'R', 'Sintesis 3', null, 'Lilith', 1018477265, 1219657442, 123456789);

insert into colaboraciones values (4, sysdate, 'Colaboracion 4', 'F', 'Sintesis 4', null, 'Morioh', 123456789, null, 1018477265);
