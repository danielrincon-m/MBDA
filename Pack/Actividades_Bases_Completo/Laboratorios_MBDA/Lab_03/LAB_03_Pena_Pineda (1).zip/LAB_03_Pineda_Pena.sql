--##C. Construcci�n: creando##
--CRUD: Registrar colaboracion
CREATE TABLE colaboracion(numero NUMBER(10) NOT NULL, fecha TIMESTAMP NOT NULL, 
            descripcion VARCHAR2(100),estado VARCHAR2(100) NOT NULL,sintesis VARCHAR2(50),
            fechaCierre TIMESTAMP,reserva VARCHAR2(100) NOT NULL, realiza NUMBER(10) NOT NULL, testigo NUMBER(10),funcionario NUMBER(10) NOT NULL);
--CRUD: Mantener archivo         
CREATE TABLE archivo(colaboracion NUMBER(10) NOT NULL,archivo VARCHAR2(100) NOT NULL);
--CRUD: Mantener unidad
CREATE TABLE unidad(numero NUMBER(10), nombre VARCHAR2(100) NOT NULL,
            departamento NUMBER(10) NOT NULL);
--CRUD: Mantener reserva
CREATE TABLE reserva(nombre VARCHAR2(100) NOT NULL, fecha TIMESTAMP NOT NULL,
            estado VARCHAR2(100) NOT NULL, detalle VARCHAR2(100));
--CRUD: Mantener foto 
CREATE TABLE foto(Turl VARCHAR2(100), autor VARCHAR2(100) NOT NULL,reserva VARCHAR2(100) NOT NULL);
--CRUD: Mantener ubicacion
CREATE TABLE ubicadaEn(reserva VARCHAR2(100) NOT NULL, porcentaje NUMBER(6),
            departamento NUMBER(10) NOT NULL);
--CRUD: Mantener departamento
CREATE TABLE departamento(identificador NUMBER(10), nombre VARCHAR2(100) NOT NULL);
--CRUD: Mantener ciudadano
CREATE TABLE ciudadano(cedula NUMBER(15) NOT NULL, nombre VARCHAR2(100) NOT NULL, 
            correo VARCHAR2(100) NOT NULL, unidad NUMBER(2));
--CRUD: Mantener funcionario
CREATE TABLE funcionario(ciudadano NUMBER(15), vinculacion TIMESTAMP NOT NULL);
--CRUD: Mantener esconocidapor
CREATE TABLE esconocidapor(reserva VARCHAR2(100) NOT NULL, funcionario NUMBER(15) NOT NULL);


--POBLAR
--TABLE reserva
INSERT INTO reserva VALUES('Tarapac�','01/05/1909','Peligro','Corregimiento departamental colombiano');
INSERT INTO reserva VALUES('Pt Alegre','02/05/1981','Peligro','Corregimiento departamental colombiano');
--TABLE foto
INSERT INTO foto VALUES('http://sea.gob.cl/regiones/region-de-tarapaca','Pedro Valenzuela Diez de Medina Director Regional','Tarapac�');
INSERT INTO foto VALUES('http://www.vinetrust.org/projects/puerto_alegria','Comunidad indigena Puerto Alegria','Pt Alegre');

--TABLE ciudadano
INSERT INTO ciudadano VALUES('1020830119','Daniel Martinez','daniel.mar@hotmail.com','1');
INSERT INTO ciudadano VALUES('5711506','Sergio Gonzalez','sergiohola@gmail.com','2');
INSERT INTO ciudadano VALUES('46351265','Carlos Castillo','carloscastiiii@gmail.com','3');
INSERT INTO ciudadano VALUES('1057571525','Ana Cortes','anitac@hotmail.com','4');
INSERT INTO ciudadano VALUES('1057582512','Ramiro Andino','ramiri�o@gmail.com','5');
INSERT INTO ciudadano VALUES('1020586987','Ernesto Linares','erneslin@hotmail.com','6');

--TABLE funcionario
INSERT INTO funcionario VALUES('1020830119','17/02/1998');
INSERT INTO funcionario VALUES('5711506','02/06/2001');
INSERT INTO funcionario VALUES('46351265','30/12/2005');
INSERT INTO funcionario VALUES('1057571525','09/01/2002');
INSERT INTO funcionario VALUES('1057582512','06/08/1999');
INSERT INTO funcionario VALUES('1020586987','25/11/2004');

--TABLE esconocidapor
INSERT INTO esconocidapor VALUES('Tarapac�','1020830119');
INSERT INTO esconocidapor VALUES('Tarapac�','5711506');
INSERT INTO esconocidapor VALUES('Tarapac�','46351265');
INSERT INTO esconocidapor VALUES('Puerto Alegre','1057571525');
INSERT INTO esconocidapor VALUES('Puerto Alegre','1057582512');
INSERT INTO esconocidapor VALUES('Puerto Alegre','1020586987');

--TABLE colaboracion
INSERT INTO colaboracion VALUES ('001','14/10/2015','Opinion acerca de la reserva LA PEDRERA','Recibida','La reserva no puede ser usada para construccion','22/10/2015','LA PEDRERA','123456784','123456786','123456789');
INSERT INTO colaboracion VALUES ('002','10/08/2012','Sugerencia sobre el uso de reserva LA PEDRERA para mineria.','Recibida','proteccion de flora y fauna','15/08/2012','LA PEDRERA','123456784','123456788','123456783');
--Otras reservas
INSERT INTO reserva VALUES('Cocuy','01/01/1977','Protegida','Reserva Forestal');
INSERT INTO reserva VALUES('Central','02/02/1994','Protegida','Reserva Forestal');
INSERT INTO reserva VALUES('Pacifico','03/03/1995','Protegida','Reserva Forestal');

INSERT INTO colaboracion VALUES ('003','15/11/2016','Opinion acerca de la reserva LA PEDRERA','Recibida','La reserva puede ser usada para construccion','22/11/2016','LA PEDRERA','12345','12345678','12345678');
INSERT INTO colaboracion VALUES ('004','11/09/2013','Sugerencia sobre el uso de reserva LA PEDRERA para CONSTRUCCION.','Recibida','proteccion de flora y fauna','15/09/2013','LA PEDRERA','123456','12345678','1234567');
--Otras reservas

--PoblarNoOK (2 y 3)
INSERT INTO ciudadano VALUES('1234567','Sergio','s@gmail.com','111');
INSERT INTO foto VALUES('https://es.wikipedia.org/wiki/La_Pedrera_(Amazonas)#/media/File:Colombia_location_map2.svg',NULL,NULL);
INSERT INTO colaboracion VALUES ('010',NULL,'Opinion Serrania Perija',NULL,'La reserva no puede ser usada para ningun otro proposito ademas de conservacion',NULL,'Serrania del Perija','123456784','Ramiro Vargas','123456');
INSERT INTO ciudadano VALUES('0000000000000000000000000000000000','Darius','darius@gmail.com','0000');
INSERT INTO ciudadano VALUES('123456',NULL,'@gmail.com','00000');
INSERT INTO reserva VALUES(NULL,NULL,'En estudio',NULL);
INSERT INTO funcionario VALUES('1234567','15-MAY-94');
INSERT INTO reserva VALUES('SERRANIA DEL PERIJA',NULL,'En estudio',NULL);
INSERT INTO funcionario VALUES('1233','10-MAY-96'); 


--Llaves 
--PRIMARIAS
ALTER TABLE departamento
ADD CONSTRAINT PK_departamento PRIMARY KEY(identificador);

ALTER TABLE unidad
ADD CONSTRAINT PK_unidad PRIMARY KEY(departamento);

ALTER TABLE ubicadaEn
ADD CONSTRAINT PK_ubicadaEn PRIMARY KEY(reserva,departamento);

ALTER TABLE reserva
ADD CONSTRAINT PK_reserva PRIMARY KEY(nombre);

ALTER TABLE foto
ADD CONSTRAINT PK_foto PRIMARY KEY(reserva);


ALTER TABLE colaboracion
ADD CONSTRAINT PK_colaboracion PRIMARY KEY(numero);


ALTER TABLE archivo
ADD CONSTRAINT PK_archivo PRIMARY KEY(colaboracion);

ALTER TABLE ciudadano
ADD CONSTRAINT PK_ciudadano PRIMARY KEY(cedula);

ALTER TABLE funcionario
ADD CONSTRAINT PK_funcionario PRIMARY KEY(ciudadano);


--ALTER TABLE esconocidapor
--ADD CONSTRAINT PK_esconocidapor PRIMARY KEY(reserva,funcionario);


--UNICAS

ALTER TABLE unidad
ADD CONSTRAINT UK_unidad UNIQUE(nombre);


ALTER TABLE foto
ADD CONSTRAINT UK_foto UNIQUE(Turl);

ALTER TABLE colaboracion
ADD CONSTRAINT UK_colaboracion UNIQUE(descripcion);




--FORANEAS
ALTER TABLE unidad
ADD CONSTRAINT FK_unidad_departamento FOREIGN KEY(departamento)
REFERENCES departamento(identificador);

ALTER TABLE ubicadaEn
ADD CONSTRAINT FK_ubicadaEn_reserva FOREIGN KEY(reserva)
REFERENCES reserva(nombre);

ALTER TABLE ubicadaEn
ADD CONSTRAINT FK_ubicadaEn_unidad FOREIGN KEY(departamento)
REFERENCES unidad(departamento);

ALTER TABLE foto
ADD CONSTRAINT FK_foto_reserva FOREIGN KEY(reserva)
REFERENCES reserva(nombre);

ALTER TABLE archivo
ADD CONSTRAINT FK_archivo_colaboracion FOREIGN KEY(colaboracion) 
REFERENCES colaboracion(numero);

ALTER TABLE colaboracion
ADD CONSTRAINT FK_colaboracion_reserva FOREIGN KEY(reserva)
REFERENCES reserva(nombre);

ALTER TABLE colaboracion
ADD CONSTRAINT FK_colaboracion_ciudadano FOREIGN KEY(realiza)
REFERENCES ciudadano(cedula);

ALTER TABLE colaboracion
ADD CONSTRAINT FK_colaboracion_funcionario FOREIGN KEY(funcionario)
REFERENCES funcionario(ciudadano);

ALTER TABLE colaboracion
ADD CONSTRAINT FK_colaboracion_ciudadano2 FOREIGN KEY(testigo)
REFERENCES ciudadano(cedula);

ALTER TABLE ciudadano
ADD CONSTRAINT FK_cuidadano_unidad FOREIGN KEY(unidad)
REFERENCES unidad(departamento);

ALTER TABLE esconocidapor
ADD CONSTRAINT FK_esconocidapor_funcionario FOREIGN KEY(funcionario)
REFERENCES funcionario(ciudadano);

ALTER TABLE esconocidapor
ADD CONSTRAINT FK_esconocidapor_reserva FOREIGN KEY(reserva)
REFERENCES reserva(nombre);




--##XTablas (Eliminar las tablas y las restricciones impuestas sobre ellas)
DROP TABLE archivo;

DROP TABLE ciudadano;

DROP TABLE colaboracion;

DROP TABLE departamento;

DROP TABLE esconocidapor;

DROP TABLE foto;

DROP TABLE funcionario;

DROP TABLE reserva;

DROP TABLE ubicadaEn;

DROP TABLE unidad;
