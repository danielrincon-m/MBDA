drop table image cascade constraints;

drop table pagos cascade constraints;

drop table permit cascade constraints;

drop table tarifas cascade constraints;

drop table vehicle cascade constraints;

drop table camera cascade constraints;

drop table keeper cascade constraints;