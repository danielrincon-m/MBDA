revoke execute on seg_admin from elAdministrador;
revoke execute on seg_ciudadano from unCiudadano;
drop package seg_admin;
drop package seg_ciudadano;