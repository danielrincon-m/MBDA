--Usuarios: unCiudadano, elAdministrador

grant execute on seg_admin to elAdministrador;
grant execute on seg_ciudadano to unCiudadano;