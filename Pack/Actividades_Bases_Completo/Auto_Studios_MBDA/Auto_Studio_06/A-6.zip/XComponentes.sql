drop package mantener_tarifas;
drop package registrar_pagos;
drop package consulta_pago_mes;
drop package consulta_tarifas;