delete from image;

delete from pagos;

delete from permit;

delete from tarifas;

delete from vehicle;

delete from camera;

delete from keeper;